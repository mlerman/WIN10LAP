#!/usr/bin/env python
import sys

for i in range(1, int(sys.argv[1]) + 1):
    print i, "X" * 78
