<?php
header("Location: ../");
die();
?>