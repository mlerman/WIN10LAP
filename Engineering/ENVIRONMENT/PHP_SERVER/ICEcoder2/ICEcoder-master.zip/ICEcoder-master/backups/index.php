<?php
header("Location: ../");
die();
?>