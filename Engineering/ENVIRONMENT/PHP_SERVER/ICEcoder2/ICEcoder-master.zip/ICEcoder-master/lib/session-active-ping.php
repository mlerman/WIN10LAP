<?php
// Load headings and settings
// Do this every 5 mins to keep session alive
include("headers.php");
include("settings.php");
?>